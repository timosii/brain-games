### Hexlet tests and linter status:
[![Actions Status](https://github.com/HoldCarter/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/HoldCarter/python-project-49/actions)
<a href="https://codeclimate.com/github/HoldCarter/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b34a0cb303d1b0b92114/maintainability" /></a>

brain-even: https://asciinema.org/a/iUpZhHnx27H2XcgXrMzgTxmAA
