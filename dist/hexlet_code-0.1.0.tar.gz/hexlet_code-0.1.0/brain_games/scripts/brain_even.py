
from even_logic import even, correct_answer

def main():
    even()



if __name__ == '__main__':
    main()

