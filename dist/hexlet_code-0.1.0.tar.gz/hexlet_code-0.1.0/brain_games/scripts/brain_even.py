#!/usr/bin/env python3
from brain_games.games.even import even_start


def main():
    even_start()


if __name__ == '__main__':
    main()
