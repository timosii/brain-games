#!/usr/bin/env python3

from brain_games.games.prime import prime_start


def main():
    prime_start()


if __name__ == '__main__':
    main()
