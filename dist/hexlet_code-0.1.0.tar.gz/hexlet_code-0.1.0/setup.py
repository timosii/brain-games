# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/HoldCarter/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/HoldCarter/python-project-49/actions)\n<a href="https://codeclimate.com/github/HoldCarter/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b34a0cb303d1b0b92114/maintainability" /></a>\n\nbrain-even: https://asciinema.org/a/iUpZhHnx27H2XcgXrMzgTxmAA\nbrain-calc: https://asciinema.org/a/3T2YYBrZ0hQUBXVOwmEfDMdVX\nbrain-gcd: https://asciinema.org/a/eWUTVdn6HXqhLu1iiWnS7Nb6L\nbrain-progression: https://asciinema.org/a/Mbhz8oOk4u41FrB7hRVo7jf2e\n',
    'author': 'HoldCarter',
    'author_email': 'holdcarter@holdcarter.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
