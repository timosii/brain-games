# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Try to fun',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/HoldCarter/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/HoldCarter/python-project-49/actions)\n<a href="https://codeclimate.com/github/HoldCarter/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b34a0cb303d1b0b92114/maintainability" /></a>\n\n## Description\nThe CLI-utility where you can play 5 simple math games.\n\n## Installation\n```\ngit clone git@github.com:timosii/brain-games.git\nmake build\nmake package-install\n```\n\n## Usage\nUse one of this commands:\n```\nbrain-even\nbrain-calc\nbrain-gcd\nbrain-progression\nbrain-prime\n```\n\n\n## Examples\n### Brain-even\n\n[![asciicast](https://asciinema.org/a/iUpZhHnx27H2XcgXrMzgTxmAA.svg)](https://asciinema.org/a/iUpZhHnx27H2XcgXrMzgTxmAA)\n\n### Brain-calc:\n\n[![asciicast](https://asciinema.org/a/3T2YYBrZ0hQUBXVOwmEfDMdVX.svg)](https://asciinema.org/a/3T2YYBrZ0hQUBXVOwmEfDMdVX)\n\n### Brain-gcd:\n\n[![asciicast](https://asciinema.org/a/eWUTVdn6HXqhLu1iiWnS7Nb6L.svg)](https://asciinema.org/a/eWUTVdn6HXqhLu1iiWnS7Nb6L)\n\n### Brain-progression:\n\n[![asciicast](https://asciinema.org/a/Mbhz8oOk4u41FrB7hRVo7jf2e.svg)](https://asciinema.org/a/Mbhz8oOk4u41FrB7hRVo7jf2e)\n\n### Brain-prime:\n\n[![asciicast](https://asciinema.org/a/FMbDFCI0VY2VjEqeHOh6Ys5rM.svg)](https://asciinema.org/a/FMbDFCI0VY2VjEqeHOh6Ys5rM)\n',
    'author': 'HoldCarter',
    'author_email': 'holdcarter@holdcarter.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/HoldCarter/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
