#!/usr/bin/env python3

from brain_games.games.gcd import gcd_start


def main():
    gcd_start()


if __name__ == '__main__':
    main()

